package org.regbyk.learn.nsk;

import javax.ejb.LocalBean;
import javax.ejb.Stateful;
import javax.enterprise.context.RequestScoped;

/**
 * Session Bean implementation class EJB1
 */
//@Stateless
@Stateful
@LocalBean
//@SessionScoped
@RequestScoped
public class EJB1 implements EJB1Remote, EJB1Local {

    /**
     * Default constructor. 
     */
    public EJB1() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String getInfo() {
		// TODO Auto-generated method stub
		return String.format("General EJB %s", this);
	}

	@Override
	public String getInfoL() {
		// TODO Auto-generated method stub
		return String.format("Local EJB %s", this);
	}

	@Override
	public String getInfoR() {
		// TODO Auto-generated method stub
		return String.format("Remote EJB %s", this);
	}

}
