package org.regbyk.learn.nsk;

import javax.ejb.Local;

@Local
public interface EJB1Local extends IInfo {

	public String getInfoL();
}
