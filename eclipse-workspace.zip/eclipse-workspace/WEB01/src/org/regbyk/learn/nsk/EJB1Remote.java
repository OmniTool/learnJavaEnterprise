package org.regbyk.learn.nsk;

import javax.ejb.Remote;

import org.regbyk.learn.nsk.IInfo;

@Remote
public interface EJB1Remote extends IInfo {

	public String getInfoR();
}
