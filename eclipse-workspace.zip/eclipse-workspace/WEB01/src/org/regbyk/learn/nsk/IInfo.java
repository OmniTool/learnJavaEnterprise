package org.regbyk.learn.nsk;

public interface IInfo {

	String getIbfo();
}
