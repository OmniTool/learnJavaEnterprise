package ru.regbyk.learn.nsk2020;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.ejb.EJB;
import javax.inject.Inject;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.regbyk.learn.nsk.EJB1;
import org.regbyk.learn.nsk.EJB1Local;
import org.regbyk.learn.nsk.EJB1Remote;

/**
 * Servlet implementation class Servlet2
 */
@WebServlet(urlPatterns= {"/Servlet2"})
public class Servlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final String JNDI_NAME_R = "java:global/EAR1/EJB01/EJB1!org.regbyk.learn.nsk.EJB1Remote";
	private String parameter;
	
	@EJB(lookup = JNDI_NAME_R)
	private EJB1Remote b1;
	//@EJB
	@Inject
	private EJB1Local b2;
	@EJB
	private EJB1 b3;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		parameter = config.getInitParameter("par1");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		Context context = null;
		
		try {
			context = new InitialContext();
			b1 = (EJB1Remote)context.lookup(JNDI_NAME_R);//JNDI ����� ������������� ���������� c ������ �������� RMI
		}
		catch (NamingException e)
		{
			
		}
		
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");
		
		try(PrintWriter out = response.getWriter())
		{
			out.println("<html><head><title>SERVLET2</title></head><body>");
			
			out.println("<h3>SERVLET222 : " + this + "</h3>");
			out.println("<h3>������� ���� : " + new Date() + "</h3>");
			out.println("<h3>par1 = " + parameter + "</h3>");
			
			out.println("<h3>EJB remote: " 
			+ (b1!=null ? b1.getInfoR() : "error........") 
			+ "</h3>");
			
			out.println("<h3>EJB local: " 
			+ (b2!=null ? b2.getInfoL() : "error........") 
			+ "</h3>");
			
			out.println("<h3>EJB common: " 
					+ (b3!=null ? b3.getInfo() : "error........") 
					+ "</h3>");
			
			out.println("</body></html>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
